@extends('layouts.app')

@section('title', 'Role Management')

@section('content')
    <div class="container-fluid">
        <div class="mb-4">
            <h1 class="page-title">Roles & Permissions</h1>
            <p class="text-muted">Overview of system roles and their access capabilities.</p>
        </div>

        <div class="row">
            @foreach($roles as $role)
                <div class="col-md-4 mb-4">
                    <div class="card h-100 border-top-{{ $role['color'] }} border-top-3">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h4 class="card-title mb-0">{{ $role['name'] }}</h4>
                                <span class="badge bg-{{ $role['color'] }}">{{ $role['slug'] }}</span>
                            </div>
                            <p class="card-text text-muted mb-4">{{ $role['description'] }}</p>

                            <h6 class="text-uppercase text-muted small fw-bold mb-3">Capabilities</h6>
                            <ul class="list-group list-group-flush">
                                @foreach($role['permissions'] as $permission)
                                    <li class="list-group-item px-0 d-flex align-items-center border-0 py-1">
                                        <i class="bi bi-check-circle-fill text-success me-2"></i>
                                        {{ $permission }}
                                    </li>
                                @endforeach
                            </ul>
                        </div>
                        <div class="card-footer bg-white border-top-0 pb-3">
                            <a href="{{ roleRoute('users.index') }}" class="btn btn-outline-{{ $role['color'] }} w-100">
                                View Users
                            </a>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
@endsection