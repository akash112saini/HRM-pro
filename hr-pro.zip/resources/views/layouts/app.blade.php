<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'HRM-Pro') }} - @yield('title')</title>

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <!-- Custom CSS -->
    <style>
        :root {
            --primary-color: #0d6efd;
            --sidebar-width: 250px;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: var(--sidebar-width);
            background: linear-gradient(180deg, #1e3a8a 0%, #1e40af 100%);
            padding-top: 20px;
            padding-bottom: 20px;
            transition: all 0.3s;
            z-index: 1000;
            overflow-y: auto;
        }

        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 12px 20px;
            margin: 2px 10px;
            border-radius: 8px;
            transition: all 0.3s;
        }

        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            background-color: rgba(255, 255, 255, 0.1);
            color: #fff;
        }

        .sidebar .nav-link i {
            margin-right: 10px;
            font-size: 1.1rem;
        }

        .main-content {
            margin-left: var(--sidebar-width);
            padding: 20px;
            min-height: 100vh;
        }

        .navbar-top {
            margin-left: var(--sidebar-width);
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.08);
        }

        .card {
            border: none;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
            border-radius: 10px;
        }

        .card-header {
            background-color: #fff;
            border-bottom: 2px solid #f0f0f0;
            font-weight: 600;
            padding: 15px 20px;
        }

        .stat-card {
            border-left: 4px solid var(--primary-color);
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
        }

        .btn-primary:hover {
            background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
        }

        .badge {
            padding: 6px 12px;
            font-weight: 500;
        }

        .table {
            background-color: #fff;
        }

        .page-title {
            font-size: 1.75rem;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 20px;
        }

        .logo-text {
            color: #fff;
            font-size: 1.5rem;
            font-weight: 700;
            padding: 10px 20px;
            margin-bottom: 30px;
        }

        @media (max-width: 768px) {
            .sidebar {
                margin-left: -250px;
            }

            .sidebar.active {
                margin-left: 0;
            }

            .main-content,
            .navbar-top {
                margin-left: 0;
                width: 100%;
            }

            .sidebar-overlay {
                display: none;
                position: fixed;
                width: 100vw;
                height: 100vh;
                background: rgba(0, 0, 0, 0.5);
                z-index: 999;
                top: 0;
                left: 0;
            }

            .sidebar-overlay.active {
                display: block;
            }
        }
    </style>
    @stack('styles')
</head>

<body>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>
    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="logo-text">
            <i class="bi bi-building"></i> HRM-Pro
        </div>

        <nav class="col-md-3 col-lg-2 d-md-block bg-dark collapse">
            <div class="position-sticky pt-3">
                <ul class="nav flex-column">
                    <!-- Dashboard (All Roles) -->
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('dashboard') ? 'active' : '' }} text-white"
                            href="{{ route('dashboard') }}">
                            <i class="bi bi-speedometer2 me-2"></i> Dashboard
                        </a>
                    </li>

                    <!-- Super Admin Only -->
                    @if(auth()->user()->role === 'super_admin')
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('super-admin.tenants.*') ? 'active' : '' }} text-white"
                                href="{{ route('super-admin.tenants.index') }}">
                                <i class="bi bi-building me-2"></i> Tenants
                            </a>
                        </li>
                    @endif

                    <!-- Admin & Super Admin -->
                    @if(in_array(auth()->user()->role, ['super_admin', 'company_admin']))
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('*.users.*') ? 'active' : '' }} text-white"
                                href="{{ roleRoute('users.index') }}">
                                <i class="bi bi-people me-2"></i> User Management
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('*.roles.*') ? 'active' : '' }} text-white"
                                href="{{ roleRoute('roles.index') }}">
                                <i class="bi bi-shield-lock me-2"></i> Roles Management
                            </a>
                        </li>
                    @endif

                    <!-- Employee Management (Admin, Manager) -->
                    @if(in_array(auth()->user()->role, ['super_admin', 'company_admin', 'manager']))
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('*.employees.*') ? 'active' : '' }} text-white"
                                href="{{ roleRoute('employees.index') }}">
                                <i class="bi bi-person-badge me-2"></i> Employees
                            </a>
                        </li>
                    @endif

                    <!-- Recruitment (Admin, Manager) -->
                    @if(in_array(auth()->user()->role, ['super_admin', 'company_admin', 'manager']))
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('jobs.*') || request()->routeIs('candidates.*') || request()->routeIs('interviews.*') ? 'active' : '' }} text-white"
                                href="#recruitmentSubmenu" data-bs-toggle="collapse">
                                <i class="bi bi-briefcase me-2"></i> Recruitment
                            </a>
                            <div class="collapse {{ request()->routeIs('jobs.*') || request()->routeIs('candidates.*') || request()->routeIs('interviews.*') ? 'show' : '' }}"
                                id="recruitmentSubmenu">
                                <ul class="nav flex-column ms-3">
                                    <li class="nav-item">
                                        <a class="nav-link {{ request()->routeIs('jobs.*') ? 'active' : '' }} text-white-50"
                                            <a
                                            class="nav-link {{ request()->routeIs('reports.attendance') ? 'active' : '' }} text-white-50"
                                            href="{{ route('reports.attendance') }}">Attendance</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link {{ request()->routeIs('reports.payroll') ? 'active' : '' }} text-white-50"
                                            href="{{ route('reports.payroll') }}">Payroll</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                    @endif

                    <!-- Settings (Admin Only) -->
                    @if(in_array(auth()->user()->role, ['super_admin', 'company_admin']))
                        <li class="nav-item">
                            <a class="nav-link {{ request()->is('settings*') || request()->routeIs('departments.*') || request()->routeIs('designations.*') || request()->routeIs('shifts.*') || request()->routeIs('devices.*') ? 'active' : '' }} text-white"
                                href="#settingsSubmenu" data-bs-toggle="collapse">
                                <i class="bi bi-gear me-2"></i> Settings
                            </a>
                            <div class="collapse {{ request()->is('settings*') || request()->routeIs('departments.*') || request()->routeIs('designations.*') || request()->routeIs('shifts.*') || request()->routeIs('devices.*') ? 'show' : '' }}"
                                id="settingsSubmenu">
                                <ul class="nav flex-column ms-3">
                                    <li class="nav-item">
                                        <a class="nav-link {{ request()->routeIs('admin.devices.*') ? 'active' : '' }} text-white-50"
                                            href="{{ route('admin.devices.index') }}">Biometric Machines</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link {{ request()->routeIs('admin.leave-types.*') ? 'active' : '' }} text-white-50"
                                            href="{{ route('admin.leave-types.index') }}">Leave Types</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link {{ request()->routeIs('admin.holidays.*') ? 'active' : '' }} text-white-50"
                                            href="{{ route('admin.holidays.index') }}">Leave Calendar</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link {{ request()->routeIs('admin.designations.*') ? 'active' : '' }} text-white-50"
                                            href="{{ route('admin.designations.index') }}">Designations</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link {{ request()->routeIs('admin.departments.*') ? 'active' : '' }} text-white-50"
                                            href="{{ route('admin.departments.index') }}">Departments</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link {{ request()->routeIs('admin.shifts.*') ? 'active' : '' }} text-white-50"
                                            href="{{ route('admin.shifts.index') }}">Shifts</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link {{ request()->routeIs('admin.tax-slabs.*') ? 'active' : '' }} text-white-50"
                                            href="{{ route('admin.tax-slabs.index') }}">Tax Slabs</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link {{ request()->routeIs('admin.salary-structures.*') ? 'active' : '' }} text-white-50"
                                            href="{{ route('admin.salary-structures.index') }}">Salary Structure</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link {{ request()->routeIs('admin.attendance.corrections.*') ? 'active' : '' }} text-white-50"
                                            href="{{ route('admin.attendance.corrections.request') }}">Punch Corrections</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                    @endif

                    <!-- Self Service (All Roles) -->
                    <li class="nav-item mt-3">
                        <h6
                            class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted text-uppercase">
                            <span>Self Service</span>
                        </h6>
                        <ul class="nav flex-column mb-2">
                            <li class="nav-item">
                                <a class="nav-link {{ request()->routeIs('*.dashboard') ? 'active' : '' }} text-white"
                                    href="{{ roleRoute('dashboard') }}">
                                    <i class="bi bi-speedometer2 me-2"></i> Dashboard
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link {{ request()->routeIs('*.attendance*') ? 'active' : '' }} text-white"
                                    href="{{ auth()->user()->role === 'company_admin' ? route('admin.attendance.index') : roleRoute('attendance') }}">
                                    <i class="bi bi-clock me-2"></i> Attendance
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link {{ request()->routeIs('*.leaves') || request()->routeIs('*.leave-requests.*') ? 'active' : '' }} text-white"
                                    href="{{ auth()->user()->role === 'company_admin' ? route('admin.leave-requests.index') : roleRoute('leaves') }}">
                                    <i class="bi bi-calendar-check me-2"></i> Leaves
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link {{ request()->routeIs('*.resignations.*') ? 'active' : '' }} text-white"
                                    href="{{ roleRoute('resignations.index') }}">
                                    <i class="bi bi-box-arrow-right me-2"></i> Resignations
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link {{ request()->routeIs('*.payslips') || request()->routeIs('*.payroll.*') ? 'active' : '' }} text-white"
                                    href="{{ auth()->user()->role === 'company_admin' ? route('admin.payroll.index') : roleRoute('payslips') }}">
                                    <i class="bi bi-cash-stack me-2"></i> Payslips
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link {{ request()->routeIs('*.documents') ? 'active' : '' }} text-white"
                                    href="{{ auth()->user()->role === 'company_admin' ? route('documents.company') : roleRoute('documents') }}">
                                    <i class="bi bi-file-earmark-text me-2"></i> Documents
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link {{ request()->routeIs('attendance.corrections.*') ? 'active' : '' }} text-white"
                                    href="{{ route('attendance.corrections.request') }}">
                                    <i class="bi bi-clock-history me-2"></i> Punch Correction
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link {{ request()->routeIs('*.profile') ? 'active' : '' }} text-white"
                                    href="{{ roleRoute('profile') }}">
                                    <i class="bi bi-person-circle me-2"></i> Profile
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </nav>
    </div>

    <!-- Top Navbar -->
    <nav class="navbar navbar-expand-lg navbar-top px-4 py-3">
        <div class="d-flex align-items-center">
            <button class="btn btn-link d-md-none me-3 p-0" id="sidebarToggle">
                <i class="bi bi-list fs-1"></i>
            </button>
            <button class="btn btn-link text-dark position-relative" data-bs-toggle="dropdown">
                <i class="bi bi-bell fs-5"></i>
                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                    3
                </span>
            </button>
            <ul class="dropdown-menu dropdown-menu-end" style="min-width: 300px;">
                <li>
                    <h6 class="dropdown-header">Notifications</h6>
                </li>
                <li><a class="dropdown-item" href="#">New leave request from John Doe</a></li>
                <li><a class="dropdown-item" href="#">Payroll generated for November</a></li>
                <li><a class="dropdown-item" href="#">Interview scheduled tomorrow</a></li>
                <li>
                    <hr class="dropdown-divider">
                </li>
                <li><a class="dropdown-item text-center" href="#">View All</a></li>
            </ul>
        </div>

        <!-- User Dropdown -->
        <div class="dropdown">
            <button class="btn btn-link text-dark d-flex align-items-center" data-bs-toggle="dropdown">
                <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center me-2"
                    style="width: 35px; height: 35px;">
                    {{ strtoupper(substr(auth()->user()->name, 0, 1)) }}
                </div>
                <span class="d-none d-md-inline">{{ auth()->user()->name }}</span>
                <i class="bi bi-chevron-down ms-2"></i>
            </button>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="#"><i class="bi bi-person me-2"></i> Profile</a></li>
                <li><a class="dropdown-item" href="#"><i class="bi bi-gear me-2"></i> Settings</a></li>
                <li>
                    <hr class="dropdown-divider">
                </li>
                <li>
                    <form method="POST" action="{{ route('logout') }}">
                        @csrf
                        <button type="submit" class="dropdown-item">
                            <i class="bi bi-box-arrow-right me-2"></i> Logout
                        </button>
                    </form>
                </li>
            </ul>
        </div>
        </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="main-content">
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-2"></i>{{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        @if(session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle me-2"></i>{{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        @yield('content')
    </main>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const sidebar = document.getElementById('sidebar');
            const sidebarOverlay = document.getElementById('sidebarOverlay');
            const sidebarToggle = document.getElementById('sidebarToggle');

            if (sidebarToggle) {
                sidebarToggle.addEventListener('click', function () {
                    sidebar.classList.toggle('active');
                    sidebarOverlay.classList.toggle('active');
                });
            }

            if (sidebarOverlay) {
                sidebarOverlay.addEventListener('click', function () {
                    sidebar.classList.remove('active');
                    sidebarOverlay.classList.remove('active');
                });
            }
        });
    </script>
    <!-- Chart.js (for dashboard) -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.js"></script>

    @stack('scripts')
</body>

</html>