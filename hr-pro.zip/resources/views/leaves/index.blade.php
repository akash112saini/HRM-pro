@extends('layouts.app')

@section('title', 'Leave Requests')
    <option value="">All Months</option>
    @foreach(range(1, 12) as $m)
        <option value="{{ $m }}" {{ request('month') == $m ? 'selected' : '' }}>
            {{ date('F', mktime(0, 0, 0, $m, 1)) }}
        </option>
    @endforeach
    </select>

    <select name="year" class="form-select" onchange="this.form.submit()">
        <option value="">All Years</option>
        @foreach(range(date('Y') - 5, date('Y') + 1) as $y)
            <option value="{{ $y }}" {{ request('year', date('Y')) == $y ? 'selected' : '' }}>
                {{ $y }}
            </option>
        @endforeach
    </select>
    </form>

    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#applyLeaveModal">
        <i class="bi bi-calendar-plus me-2"></i>Apply Leave
    </button>
    </div>
    </div>

    <!-- Filter Tabs -->
    <ul class="nav nav-pills mb-4">
        <li class="nav-item">
            <a class="nav-link {{ request('status', 'all') == 'all' ? 'active' : '' }}" href="?status=all">
                All Requests
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link {{ request('status') == 'pending' ? 'active' : '' }}" href="?status=pending">
                <span class="badge bg-warning text-dark">{{ $counts['pending'] ?? 8 }}</span> Pending
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link {{ request('status') == 'approved' ? 'active' : '' }}" href="?status=approved">
                <span class="badge bg-success">{{ $counts['approved'] ?? 45 }}</span> Approved
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link {{ request('status') == 'rejected' ? 'active' : '' }}" href="?status=rejected">
                <span class="badge bg-danger">{{ $counts['rejected'] ?? 5 }}</span> Rejected
            </a>
        </li>
    </ul>

    <!-- Leave Balance Overview -->
    <div class="row g-4 mb-4">
        <div class="col-md-3">
            <div class="card border-start border-primary border-4">
                <div class="card-body">
                    <small class="text-muted">Casual Leave</small>
                    <h4 class="mb-0">8.5 <small class="text-muted">/ 12</small></h4>
                    <div class="progress mt-2" style="height: 5px;">
                        <div class="progress-bar bg-primary" style="width: 71%"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-start border-danger border-4">
                <div class="card-body">
                    <small class="text-muted">Sick Leave</small>
                    <h4 class="mb-0">10 <small class="text-muted">/ 12</small></h4>
                    <div class="progress mt-2" style="height: 5px;">
                        <div class="progress-bar bg-danger" style="width: 83%"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-start border-success border-4">
                <div class="card-body">
                    <small class="text-muted">Privilege Leave</small>
                    <h4 class="mb-0">12 <small class="text-muted">/ 15</small></h4>
                    <div class="progress mt-2" style="height: 5px;">
                        <div class="progress-bar bg-success" style="width: 80%"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-start border-warning border-4">
                <div class="card-body">
                    <small class="text-muted">Carry Forward</small>
                    <h4 class="mb-0">5 <small class="text-muted">days</small></h4>
                    <small class="text-muted">From previous year</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Leave Requests List -->
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Employee</th>
                            <th>Leave Type</th>
                            <th>From - To</th>
                            <th>Duration</th>
                            <th>Reason</th>
                            <th>Applied On</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($leaveRequests as $leave)
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center me-2"
                                            style="width: 32px; height: 32px; font-size: 0.85rem;">
                                            {{ strtoupper(substr($leave->employee->first_name, 0, 1) . substr($leave->employee->last_name, 0, 1)) }}
                                        </div>
                                        <div>
                                            <div class="fw-bold">{{ $leave->employee->full_name }}</div>
                                            <small class="text-muted">{{ $leave->employee->department->name ?? 'N/A' }}</small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    @php
                                        $typeColors = [
                                            'Casual Leave' => 'primary',
                                            'Sick Leave' => 'danger',
                                            'Privilege Leave' => 'success'
                                        ];
                                    @endphp
                                    <span
                                        class="badge bg-{{ $typeColors[$leave->leaveType->name] ?? 'secondary' }}-subtle text-{{ $typeColors[$leave->leaveType->name] ?? 'secondary' }}">
                                        {{ $leave->leaveType->name }}
                                    </span>
                                </td>
                                <td>
                                    <small>
                                        {{ $leave->start_date->format('d M') }} - {{ $leave->end_date->format('d M Y') }}
                                    </small>
                                </td>
                                <td>
                                    <strong>{{ $leave->total_days }} {{ $leave->total_days > 1 ? 'days' : 'day' }}</strong>
                                </td>
                                <td>
                                    <span class="text-truncate d-inline-block" style="max-width: 200px;"
                                        title="{{ $leave->reason }}">
                                        {{ $leave->reason }}
                                    </span>
                                </td>
                                <td><small class="text-muted">{{ $leave->applied_at->format('d M Y') }}</small></td>
                                <td>
                                    @php
                                        $statusColors = [
                                            'pending' => 'warning',
                                            'approved' => 'success',
                                            'rejected' => 'danger',
                                            'cancelled' => 'secondary'
                                        ];
                                    @endphp

                                    <!-- Reject Modal -->
                                    <div class="modal fade" id="rejectModal{{ $leave->id }}" tabindex="-1">
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">Cancel</button>
                                                        <button type="submit" class="btn btn-danger">Reject Leave</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                        @empty
                                    <tr>
                                        <td colspan="8" class="text-center py-4">
                                            <i class="bi bi-inbox fs-1 text-muted"></i>
                                            <p class="text-muted mt-2">No leave requests found</p>
                                        </td>
                                    </tr>
                                @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="mt-4">
        {{ $leaveRequests->links() }}
    </div>
    </div>

    <!-- Apply Leave Modal -->
    <div class="modal fade" id="applyLeaveModal" tabindex="-1">
        <div class="modal-dialog">
                                @foreach($leaveTypes ?? [] as $type)
                                    <option value="{{ $type->id }}">{{ $type->name }} ({{ $balances[$type->id] ?? 0 }}
                                        available)</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Start Date</label>
                                <input type="date" name="start_date" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">End Date</label>
                                <input type="date" name="end_date" class="form-control" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Reason</label>
                            <textarea name="reason" class="form-control" rows="3" required
                                placeholder="Enter reason for leave"></textarea>
                        </div>
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle me-2"></i>
                            Your leave request will be sent to your manager for approval.
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Submit Request</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection