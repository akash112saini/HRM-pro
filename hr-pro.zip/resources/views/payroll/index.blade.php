@extends('layouts.app')

                                            @endif
                                        </div>
                                    </td>
                                </tr>

                                <!-- Mark as Paid Modal -->
                                <div class="modal fade" id="markPaidModal{{ $payroll->id }}" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Mark as Paid</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <form method="POST" action="{{ roleRoute('payroll.mark-paid', $payroll) }}">
                                                @csrf
                                                <div class="modal-body">
                                                    <p>Mark payroll for <strong>{{ $payroll->employee->full_name }}</strong> as
                                                        paid?</p>
                                                    <div class="mb-3">
                                                        <label class="form-label">Payment Method</label>
                                                        <select name="payment_method" class="form-select" required>
                                                            <option value="bank_transfer">Bank Transfer</option>
                                                            <option value="cash">Cash</option>
                                                            <option value="cheque">Cheque</option>
                                                        </select>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label">Transaction Reference</label>
                                                        <input type="text" name="transaction_reference" class="form-control"
                                                            placeholder="Enter reference number">
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal">Cancel</button>
                                                    <button type="submit" class="btn btn-success">Confirm Payment</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            @empty
                                <tr>
                                    <td colspan="8" class="text-center py-4">
                                        <i class="bi bi-inbox fs-1 text-muted"></i>
                                        <p class="text-muted mt-2">No payroll records found for this period</p>
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Pagination -->
        <div class="mt-4">
            {{ $payrolls->links() }}
        </div>
    </div>
@endsection