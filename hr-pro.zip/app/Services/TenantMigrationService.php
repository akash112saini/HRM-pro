<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Artisan;
use App\Models\Tenant;

class TenantMigrationService
{
    /**
     * Create a new database for the tenant.
     */
    public function createDatabase(Tenant $tenant)
    {
        $databaseName = 'hrmpro_tenant_' . $tenant->id;

        // Use the default connection (e.g., mysql) to create the new database
        DB::connection('mysql')->statement("CREATE DATABASE IF NOT EXISTS `{$databaseName}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

        return $databaseName;
    }

    /**
     * Run migrations for a specific tenant.
     */
    public function migrate(Tenant $tenant, $fresh = false)
    {
        $databaseName = 'hrmpro_tenant_' . $tenant->id;

        // Set the tenant database connection dynamically
        Config::set('database.connections.tenant.database', $databaseName);
        DB::purge('tenant');
        DB::reconnect('tenant');

        $command = $fresh ? 'migrate:fresh' : 'migrate';

        // Run migrations on the tenant connection
        Artisan::call($command, [
            '--database' => 'tenant',
            '--path' => 'database/migrations/tenant', // We will move tenant-specific migrations here
            '--force' => true,
        ]);

        return Artisan::output();
    }

    /**
     * Seed the tenant database.
     */
    public function seed(Tenant $tenant, $class = 'DatabaseSeeder')
    {
        $databaseName = 'hrmpro_tenant_' . $tenant->id;

        Config::set('database.connections.tenant.database', $databaseName);
        DB::purge('tenant');
        DB::reconnect('tenant');

        Artisan::call('db:seed', [
            '--database' => 'tenant',
            '--class' => $class,
            '--force' => true,
        ]);

        return Artisan::output();
    }
}
