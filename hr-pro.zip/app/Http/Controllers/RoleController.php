<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RoleController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // Define system roles and their capabilities
        $roles = [
            [
                'name' => 'Company Admin',
                'slug' => 'company_admin',
                'description' => 'Full access to all modules and settings within the company.',
                'permissions' => [
                    'Manage Employees',
                    'Manage Payroll',
                    'Manage Attendance',
                    'Manage Leaves',
                    'Manage Recruitment',
                    'Manage Assets',
                    'Manage Settings',
                    'Manage Users'
                ],
                'color' => 'danger'
            ],
            [
                'name' => 'Manager',
                'slug' => 'manager',
                'description' => 'Access to manage their team members and view reports.',
                'permissions' => [
                    'View Team Employees',
                    'Approve Leaves',
                    'Approve Attendance',
                    'View Team Performance',
                    'Conduct Appraisals'
                ],
                'color' => 'warning'
            ],
            [
                'name' => 'Employee',
                'slug' => 'employee',
                'description' => 'Access to self-service portal.',
                'permissions' => [
                    'View Own Profile',
                    'Mark Attendance',
                    'Apply Leave',
                    'View Payslips',
                    'View Own Performance'
                ],
                'color' => 'info'
            ]
        ];

        return view('roles.index', compact('roles'));
    }
}
